from django.urls import  path
from . import views
urlpatterns = [
    path('', views.home, name='home'),
    path('casestatus', views.case_status, name='case_status'),
    path('check-case', views.check_case, name='check_case'),
]
from django.shortcuts import render
from .scraper import fetch_case_by_cnr, check_case_in_list
from datetime import datetime, timedelta

def home(request):
    if request.method == 'POST':
        cnr = request.POST.get('cnr', '').strip()
        date_option = request.POST.get('date_option')  # today/tomorrow

        if not cnr:
            return render(request, 'index.html', {"error": "Please enter a CNR number."})

        if date_option == 'tomorrow':
            date_str = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
        else:
            date_str = datetime.now().strftime("%Y-%m-%d")

        case_data = fetch_case_by_cnr(cnr)
        list_check = check_case_in_list(cnr, date_str)

        # build context safely from returned dicts
        context = {
            "cnr": cnr,
            "date_checked": date_str,
            "case_info": case_data.get("case_info") if isinstance(case_data, dict) else None,
            "case_html": case_data.get("case_html") if isinstance(case_data, dict) else None,
            "found": list_check.get("found", False) if isinstance(list_check, dict) else False,
            "serial_number": list_check.get("serial_number") if isinstance(list_check, dict) else None,
            "court_name": list_check.get("court_name") if isinstance(list_check, dict) else None,
            "error": None
        }

        # surface any scraper errors
        if isinstance(case_data, dict) and case_data.get("error"):
            context["error"] = case_data.get("error")
        if isinstance(list_check, dict) and list_check.get("error"):
            # append cause list error to context.error
            if context["error"]:
                context["error"] += " | " + list_check.get("error")
            else:
                context["error"] = list_check.get("error")

        return render(request, 'result.html', {"result": context})

    return render(request, 'index.html')


from django.shortcuts import render, redirect


def home(request):
    """Render the home page with CNR search form"""
    return render(request, 'index.html')


def check_case(request):
    """Handle CNR case checking"""
    if request.method == 'POST':
        cnr = request.POST.get('cnr', '').strip()
        date_option = request.POST.get('date_option', '')

        # Validate CNR
        if len(cnr) != 16:
            result = {
                'cnr': cnr,
                'date_checked': date_option,
                'found': False,
                'case_info': 'Invalid CNR Number. Must be exactly 16 characters.'
            }
            return render(request, 'result.html', {'result': result})

        # Your scraping logic here
        # Example result structure:
        result = {
            'cnr': cnr,
            'date_checked': date_option,
            'found': True,  # Change based on your scraping result
            'serial_number': 'S123',  # From scraping
            'court_name': 'District Court, Chennai',  # From scraping
            'case_info': 'Case details will appear here from scraping...'  # From scraping
        }

        return render(request, 'result.html', {'result': result})

    return redirect('/')


def case_status(request):
    """Handle case status checking"""
    if request.method == 'POST':
        case_type = request.POST.get('case_type', '')
        case_number = request.POST.get('case_number', '')
        case_year = request.POST.get('case_year', '')

        # Your case status scraping logic here
        # Example result structure:
        result = {
            'case_type': case_type.upper(),
            'case_number': case_number,
            'case_year': case_year,
            'status': 'Pending',  # From scraping
            'next_hearing': '2024-12-15',  # From scraping
            'case_info': f'Case Type: {case_type.upper()}\nCase Number: {case_number}\nYear: {case_year}\n\nStatus details from scraping will appear here...'
        }

        return render(request, 'result.html', {'result': result})

    return render(request, 'casestatus.html')





import requests
from bs4 import BeautifulSoup
from datetime import datetime, timedelta

BASE_URL = "https://services.ecourts.gov.in/ecourtindia_v6"

HEADERS = {
    "User-Agent": "Mozilla/5.0 (compatible; eCourtScraper/1.0; +https://example.com)"
}

def fetch_case_by_cnr(cnr):
    """Fetch case details using CNR number."""
    url = f"{BASE_URL}/case_detail/case_detail.php"
    params = {"cnr_no": cnr.strip(), "state_cd": "", "dist_cd": "", "court_cd": ""}
    try:
        resp = requests.get(url, params=params, headers=HEADERS, timeout=15)
    except requests.RequestException as e:
        return {"error": f"Connection error: {e}"}
    if resp.status_code != 200:
        return {"error": f"HTTP {resp.status_code} when fetching case detail"}
    soup = BeautifulSoup(resp.text, "html.parser")
    # Return raw HTML snippet as fallback and some cleaned text
    return {"case_html": str(soup), "case_info": soup.get_text(separator="\n", strip=True)}

def fetch_cause_list_html(date_str):
    """Return BeautifulSoup object for cause list page for date_str."""
    url = f"{BASE_URL}/cause_list/cause_list.php"
    params = {"date": date_str}
    try:
        resp = requests.get(url, params=params, headers=HEADERS, timeout=15)
    except requests.RequestException as e:
        return {"error": f"Connection error: {e}", "soup": None}
    if resp.status_code != 200:
        return {"error": f"HTTP {resp.status_code} when fetching cause list", "soup": None}
    soup = BeautifulSoup(resp.text, "html.parser")
    return {"error": None, "soup": soup}

def check_case_in_list(cnr, date_str):
    """
    Check whether CNR appears in the cause list for date_str.
    If found, tries to extract serial number and court name from nearby HTML structure.
    Returns a dict (always).
    """
    res = fetch_cause_list_html(date_str)
    if res["soup"] is None:
        return {"found": False, "error": res["error"], "serial_number": None, "court_name": None}

    soup = res["soup"]

    # Strategy:
    # 1) Try to find elements containing the CNR (anchor, td, div etc.)
    # 2) If found, search parent/ancestor elements for serial/court info
    # 3) Fall back to searching text-lines

    # 1) direct search for an element that contains the exact CNR text
    element = soup.find(lambda tag: tag.string and cnr in tag.string)
    if not element:
        # maybe inside attributes or more complex structure: search by text
        element = soup.find(text=lambda t: t and cnr in t)
        if element:
            element = element.parent

    if not element:
        # fallback: search the whole page text
        text = soup.get_text(separator="\n")
        if cnr in text:
            # fallback to line scanning
            lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
            for i, ln in enumerate(lines):
                if cnr in ln:
                    # look earlier lines for court/serial keywords
                    serial = None
                    court = None
                    for j in range(max(0, i-6), i):
                        l = lines[j]
                        if serial is None and ("Serial" in l or "Sl." in l or "S.No" in l or l.lower().startswith("sl")):
                            serial = l
                        if court is None and ("Court" in l or "Bench" in l or l.lower().startswith("court")):
                            court = l
                    return {"found": True, "error": None, "serial_number": serial, "court_name": court}
        # not found anywhere
        return {"found": False, "error": None, "serial_number": None, "court_name": None}

    # If we have an element that contains the CNR, search up for container rows / headings
    serial_number = None
    court_name = None

    # search ancestors for a row-like element
    ancestor = element
    for _ in range(6):  # go up a few levels
        if ancestor is None:
            break
        # if ancestor is a table row or div with class indicating row, look for serial/court inside it or previous siblings
        if ancestor.name in ("tr", "div", "section", "li"):
            # search this ancestor for possible serial/court labels
            txt = ancestor.get_text(separator="|", strip=True)
            if not serial_number:
                # try to extract patterns like "S. No: 12" or "Sl. No. 5"
                if "Serial" in txt or "Sl." in txt or "S.No" in txt or "S. No" in txt:
                    serial_number = txt
            if not court_name:
                if "Court" in txt or "Bench" in txt:
                    court_name = txt

            # also check previous sibling (sometimes heading is above the row)
            prev = ancestor.find_previous_sibling()
            if prev:
                prev_txt = prev.get_text(separator="|", strip=True)
                if not court_name and ("Court" in prev_txt or "Bench" in prev_txt):
                    court_name = prev_txt
                if not serial_number and ("Serial" in prev_txt or "Sl." in prev_txt):
                    serial_number = prev_txt

            # check parent heading tags
            parent_h = ancestor.find_parent(["h1", "h2", "h3", "h4", "h5"])
            if parent_h:
                ptxt = parent_h.get_text(strip=True)
                if not court_name and ("Court" in ptxt or "Bench" in ptxt):
                    court_name = ptxt

        ancestor = ancestor.parent

    # If still not found, as a last resort try to scan page text lines near CNR occurrence
    if not serial_number or not court_name:
        page_lines = [ln.strip() for ln in soup.get_text(separator="\n").splitlines() if ln.strip()]
        for i, ln in enumerate(page_lines):
            if cnr in ln:
                for j in range(max(0, i-6), i):
                    l = page_lines[j]
                    if not serial_number and ("Serial" in l or "Sl." in l or "S.No" in l):
                        serial_number = l
                    if not court_name and ("Court" in l or "Bench" in l):
                        court_name = l
                break

    return {"found": True, "error": None, "serial_number": serial_number, "court_name": court_name}

